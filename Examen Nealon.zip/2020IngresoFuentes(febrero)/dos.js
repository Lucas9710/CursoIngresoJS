function mostrar() {
  var respuesta = "s";
  var peso;
  var precioPorKg=0;
  var precioTotal;
  var ingrediente;
  var pesoTotal=0;
  var sumaTotal=0;
  var primera = true;
  var precioMasCaro=0;
  var cont=0;
  var sumaPrecios=0;
  var descuentoQuince;
  var descuentoVeinticinco;
  var totalConQuince;
  var alimentoMasCaro;
  var promedioPesoPorKg;
  do {
    do {
      peso = parseInt(prompt("Ingrese el peso"));
    } while (peso < 10 || peso > 1000 || isNaN(peso));
    do {
      precioPorKg = parseInt(prompt("Ingrese el precio por kg"));
    } while (precioPorKg < 0 || isNaN(precioPorKg));
    precioTotal = precioPorKg * peso;
    do {
      ingrediente = prompt("Ingrese tipo de ingrediente (v, a, m)");
    } while ((ingrediente != "v") && (ingrediente != "a") && (ingrediente != "m"));
    pesoTotal = pesoTotal + peso;
    sumaTotal = sumaTotal + precioTotal;
    if (primera) {
      alimentoMasCaro = ingrediente;
      precioMasCaro = precioPorKg;
      primera = false;
    }
    if (precioMasCaro < precioPorKg) {
      alimentoMasCaro = ingrediente;
      precioMasCaro = precioPorKg;
    }
    sumaPrecios = sumaPrecios + precioPorKg;
    cont++;
    respuesta = prompt("Desea ingresar otra compra? s/n");
  } while (respuesta == "s");
  promedioPesoPorKg = sumaPrecios/cont;
  if (pesoTotal > 100 && pesoTotal < 300) {
    descuentoQuince = sumaTotal * 0.15;
    totalConQuince = sumaTotal - descuentoQuince;
  }
  if (pesoTotal > 300) {
    descuentoVeinticinco = sumaTotal * 0.25;
    totalConVeinticinco = sumaTotal - descuentoVeinticinco;
  }
  alert("El importe total a pagar es " + sumaTotal + " sin descuentos");
  if (pesoTotal > 100 && pesoTotal < 300) {
    alert("El importe a pagar es " + totalConQuince + " con 15% de descuento");
  }
  if (pesoTotal > 300) {
    alert("El importe a pagar es " + totalConVeinticinco + " con 25% de descuento");
  }
  alert("El alimento más caro fue " + alimentoMasCaro);
  alert("El promedio del precio por kg fue de " + promedioPesoPorKg);
}
