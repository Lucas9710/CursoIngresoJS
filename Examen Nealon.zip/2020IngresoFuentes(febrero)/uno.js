function mostrar() {
	var producto;
	var precio;
	var unidades;
	var marca;
	var primera = true;
	var precioBarbijosCaros;
	var unidadesBarbijosCaros;
	var fabricanteBarbijosCaros;
	var cantidadDeUnidades = 0;
	var fabricanteConMasUnidades;
	var unidadesDeJabon=0;
	for (var i = 0 ; i < 5; i++) {
		do {
		producto = prompt("Ingrese un producto de prevención de contagio");
		} while (producto != "barbijo" && producto != "jabon" && producto != "alcohol");
		do {
			precio = parseInt(prompt("Ingrese el valor del producto"));
		} while (precio < 100 || precio > 300 || isNaN(precio));
		do {
			unidades = parseInt(prompt("Ingrese la cantidad de unidades"));
		} while (unidades < 0 || unidades > 1000 || isNaN(unidades));
		marca = prompt("Ingrese la marca del producto");
		fabricante = prompt("Ingrese el fabricante del producto");
		if (primera && producto != "barbijo") {
			precioBarbijosCaros = 0;
			unidadesBarbijosCaros = 0;
			fabricanteBarbijosCaros = "No hay barbijos ingresados";
			primera = false;
		}
		else { 
			if (primera) {
				precioBarbijosCaros = precio;
				unidadesBarbijosCaros = unidades;
				fabricanteBarbijosCaros = fabricante;
				primera = false;
			}
		}
		if (producto == "barbijo" && precioBarbijosCaros < precio) {
			precioBarbijosCaros = precio;
			unidadesBarbijosCaros= unidades;
			fabricanteBarbijosCaros = fabricante;
		}
		if (cantidadDeUnidades < unidades) {
			fabricanteConMasUnidades = fabricante;
		}
		if (producto == "jabon") {
			unidadesDeJabon = unidadesDeJabon + unidades;
		}
	}
	alert ("Se ingresaron " + unidadesBarbijosCaros + " unidades de los barbijos más caros, fabricados por " + fabricanteBarbijosCaros);
	alert ("El fabricante " + fabricanteConMasUnidades + " es el que ingresó mayor cantidad de unidades");
	alert ("La cantidad de jabones ingresada es de " + unidadesDeJabon);
}
