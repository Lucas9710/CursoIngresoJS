function mostrar() {
	var nombre;
	var edad;
	var sexo;
	var estado;
	var respuesta = "s";
	var primera = true;
	var edadCasadoMasJoven;
	var nombreCasadoMasJoven;
	var edadMayor;
	var sexoMayor;
	var nombreMayor;
	var sumaEdadesMujeres=0;
	var contM=0;
	var promedioEdadesMujeres;
	var sumaEdadesHombres=0;
	var contH=0;
	var promedioEdadesHombres;
	var mujeresCasadas=0;
	var mujeresViudas=0;
	do {
		nombre = prompt("Ingrese el nombre del pasajero");
		do {
			edad = parseInt(prompt("Ingrese la edad del pasajero"));
		} while (edad < 18 || isNaN(edad));
		do {
			sexo = prompt("Ingrese el sexo del pasajero (f/m)");
		} while (sexo != "f" && sexo != "m");
		do {
			estado = prompt("Ingrese el estado civil del pasajero (en género masculino)");
		} while (estado != "soltero" && estado != "casado" && estado != "viudo");
		if (primera && sexo == "m" && estado == "casado") {
			nombreCasadoMasJoven = nombre;
			edadCasadoMasJoven = edad;
			edadMayor = edad;
			sexoMayor = sexo;
			nombreMayor = nombre;
			primera = false;
		}
		else {
			edadMayor = edad;
			sexoMayor = sexo;
			nombreMayor = nombre;
			primera = false;
		}
		if (sexo == "m" && edad < edadCasadoMasJoven && estado == "casado") {
			nombreCasadoMasJoven = nombre;
			edadCasadoMasJoven = edad;
		}
		if (edadMayor < edad) {
			edadMayor = edad;
			sexoMayor = sexo;
			nombreMayor = nombre;
		}
		if (sexo == "f") {
			sumaEdadesMujeres = sumaEdadesMujeres + edad;
			contM++;
		}
		if (sexo == "f" && estado == "casado") {
			mujeresCasadas++;
		}
		if (sexo == "f" && estado == "viudo") {
			mujeresViudas++;
		}
		if (sexo == "m" && estado == "soltero") {
			sumaEdadesHombres = sumaEdadesHombres + edad;
			contH++;
		}
		respuesta = prompt("¿Faltan cargar pasajeros? s/n");
	} while (respuesta == "s");
	promedioEdadesMujeres = sumaEdadesMujeres/contM;
	promedioEdadesHombres = sumaEdadesHombres/contH;
	if (isNaN(edadCasadoMasJoven)) {
		alert("No hay hombres casados que viajen");
	}
	else {
	alert("El nombre del hombre casado más joven es " + nombreCasadoMasJoven);
	}
	alert("El nombre del pasajero más viejo es " + nombreMayor + " y su sexo es " + sexoMayor);
	alert ("La cantidad de mujeres casadas es " + mujeresCasadas + " y la de viudas es " + mujeresViudas);
	alert("El promedio de edades de mujeres es " + promedioEdadesMujeres);
	alert("El promedio de edades de hombres solteros es " + promedioEdadesHombres);
}
